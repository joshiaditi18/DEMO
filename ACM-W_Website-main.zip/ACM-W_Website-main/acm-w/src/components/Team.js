import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FaLinkedin, FaGithub, FaEnvelope, FaCrown, FaUsers, FaStar } from 'react-icons/fa';
import { useInView } from 'react-intersection-observer';
import '../css/Team.css';

const Team = ({ darkMode }) => {
  const [selectedMember, setSelectedMember] = useState(null);
  const [activeFilter, setActiveFilter] = useState('all');

  // Intersection Observer hooks
  const [heroRef, heroInView] = useInView({ threshold: 0.1, triggerOnce: true });
  const [teamRef, teamInView] = useInView({ threshold: 0.1, triggerOnce: true });

  const teamMembers = {
    leadership: [
      {
        id: 1,
        name: "Prastuti Motghare",
        role: "President",
        image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80",
        department: "Computer Engineering",
        year: "Final Year",
        linkedin: "https://linkedin.com/in/prastuti-motghare",
        github: "https://github.com/prastuti",
        email: "prastuti.motghare@example.com",
        description: "Leading ACM-W PCCOE with passion and dedication. Experienced in web development and community building.",
        achievements: ["Best Student Chapter Award 2023", "Hackathon Winner 2024", "Mentored 50+ students"],
        skills: ["React", "Node.js", "Leadership", "Community Management"]
      },
      {
        id: 2,
        name: "Shravani Pande",
        role: "Vice President",
        image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80",
        department: "Computer Engineering",
        year: "Final Year",
        linkedin: "https://linkedin.com/in/shravani-pande",
        github: "https://github.com/shravani",
        email: "shravani.pande@example.com",
        description: "Driving innovation and technical excellence in our community. Specialized in AI/ML and competitive programming.",
        achievements: ["Google Code Jam Qualifier", "AI Research Paper Published", "Technical Lead for 10+ projects"],
        skills: ["Python", "Machine Learning", "Competitive Programming", "Project Management"]
      },
      {
        id: 3,
        name: "Tejashree Panaskar",
        role: "Secretary",
        image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80",
        department: "Computer Engineering",
        year: "Third Year",
        linkedin: "https://linkedin.com/in/tejashree-panaskar",
        github: "https://github.com/tejashree",
        email: "tejashree.panaskar@example.com",
        description: "Organizing events and managing communications. Passionate about creating inclusive tech communities.",
        achievements: ["Event Management Excellence", "Community Outreach Leader", "Technical Workshop Organizer"],
        skills: ["Event Management", "Communication", "UI/UX Design", "Team Coordination"]
      }
    ],
    core: [
      {
        id: 4,
        name: "Priya Sharma",
        role: "Technical Lead",
        image: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80",
        department: "Computer Engineering",
        year: "Third Year",
        linkedin: "https://linkedin.com/in/priya-sharma",
        github: "https://github.com/priya",
        email: "priya.sharma@example.com",
        description: "Leading technical initiatives and mentoring junior members. Expert in full-stack development.",
        achievements: ["Full Stack Developer", "Mentored 30+ students", "Technical Workshop Instructor"],
        skills: ["JavaScript", "React", "Node.js", "MongoDB"]
      },
      {
        id: 5,
        name: "Anjali Patel",
        role: "Outreach Coordinator",
        image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80",
        department: "Computer Engineering",
        year: "Third Year",
        linkedin: "https://linkedin.com/in/anjali-patel",
        github: "https://github.com/anjali",
        email: "anjali.patel@example.com",
        description: "Building partnerships and expanding our network. Focused on community engagement and growth.",
        achievements: ["Partnership Manager", "Community Growth Expert", "Event Coordinator"],
        skills: ["Networking", "Partnership Building", "Communication", "Project Planning"]
      },
      {
        id: 6,
        name: "Neha Gupta",
        role: "Content Lead",
        image: "https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80",
        department: "Computer Engineering",
        year: "Second Year",
        linkedin: "https://linkedin.com/in/neha-gupta",
        github: "https://github.com/neha",
        email: "neha.gupta@example.com",
        description: "Creating engaging content and managing our digital presence. Passionate about tech writing and design.",
        achievements: ["Content Creator", "Social Media Manager", "Design Enthusiast"],
        skills: ["Content Writing", "Graphic Design", "Social Media", "UI/UX"]
      }
    ],
    members: [
      {
        id: 7,
        name: "Riya Singh",
        role: "Member",
        image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80",
        department: "Computer Engineering",
        year: "Second Year",
        linkedin: "https://linkedin.com/in/riya-singh",
        github: "https://github.com/riya",
        email: "riya.singh@example.com",
        description: "Active member contributing to various projects and events. Learning and growing with the community.",
        achievements: ["Hackathon Participant", "Workshop Attendee", "Community Contributor"],
        skills: ["Python", "Web Development", "Team Collaboration"]
      },
      {
        id: 8,
        name: "Kavya Reddy",
        role: "Member",
        image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80",
        department: "Computer Engineering",
        year: "Second Year",
        linkedin: "https://linkedin.com/in/kavya-reddy",
        github: "https://github.com/kavya",
        email: "kavya.reddy@example.com",
        description: "Passionate about data science and machine learning. Contributing to technical projects and learning initiatives.",
        achievements: ["Data Science Enthusiast", "ML Workshop Participant", "Project Contributor"],
        skills: ["Python", "Machine Learning", "Data Analysis", "Statistics"]
      }
    ]
  };

  const filters = [
    { id: 'all', label: 'All Members', icon: <FaUsers /> },
    { id: 'leadership', label: 'Leadership', icon: <FaCrown /> },
    { id: 'core', label: 'Core Team', icon: <FaStar /> },
    { id: 'members', label: 'Members', icon: <FaUsers /> }
  ];

  const getFilteredMembers = () => {
    if (activeFilter === 'all') {
      return [...teamMembers.leadership, ...teamMembers.core, ...teamMembers.members];
    }
    return teamMembers[activeFilter] || [];
  };

  const handleMemberClick = (member) => {
    setSelectedMember(member);
  };

  const closeModal = () => {
    setSelectedMember(null);
  };

  return (
    <div className={`team-page ${darkMode ? 'dark-mode' : ''}`}>
      {/* Hero Section */}
      <section 
        ref={heroRef}
        className={`team-hero ${heroInView ? 'animate' : ''}`}
      >
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={heroInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="hero-content"
          >
            <h1>Meet Our Team</h1>
            <p className="hero-subtitle">
              The passionate individuals driving innovation and empowerment in our community
            </p>
            <p className="hero-description">
              Our diverse team of leaders, innovators, and changemakers work together to create 
              opportunities and foster growth for women in computing and technology.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Team Section */}
      <section 
        ref={teamRef}
        className="team-section"
      >
        <div className="container">
          {/* Filter Buttons */}
          <div className="filter-container">
            {filters.map((filter) => (
              <button
                key={filter.id}
                className={`filter-button ${activeFilter === filter.id ? 'active' : ''}`}
                onClick={() => setActiveFilter(filter.id)}
              >
                <span className="filter-icon">{filter.icon}</span>
                {filter.label}
              </button>
            ))}
          </div>

          {/* Team Grid */}
          <div className="team-grid">
            {getFilteredMembers().map((member, index) => (
              <motion.div
                key={member.id}
                className="team-card"
                initial={{ opacity: 0, y: 30 }}
                animate={teamInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                onClick={() => handleMemberClick(member)}
              >
                <div className="member-image">
                  <img src={member.image} alt={member.name} />
                  <div className="member-overlay">
                    <span>View Profile</span>
                  </div>
                </div>
                <div className="member-info">
                  <h3>{member.name}</h3>
                  <p className="member-role">{member.role}</p>
                  <p className="member-department">{member.department} • {member.year}</p>
                  <div className="member-social">
                    <a href={member.linkedin} target="_blank" rel="noopener noreferrer">
                      <FaLinkedin />
                    </a>
                    <a href={member.github} target="_blank" rel="noopener noreferrer">
                      <FaGithub />
                    </a>
                    <a href={`mailto:${member.email}`}>
                      <FaEnvelope />
                    </a>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Member Modal */}
      {selectedMember && (
        <div className="modal-overlay" onClick={closeModal}>
          <motion.div
            className="member-modal"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={(e) => e.stopPropagation()}
          >
            <button className="modal-close" onClick={closeModal}>×</button>
            <div className="modal-content">
              <div className="modal-header">
                <img src={selectedMember.image} alt={selectedMember.name} />
                <div className="modal-info">
                  <h2>{selectedMember.name}</h2>
                  <p className="modal-role">{selectedMember.role}</p>
                  <p className="modal-department">{selectedMember.department} • {selectedMember.year}</p>
                </div>
              </div>
              <div className="modal-body">
                <p className="modal-description">{selectedMember.description}</p>
                
                <div className="modal-section">
                  <h3>Achievements</h3>
                  <ul className="achievements-list">
                    {selectedMember.achievements.map((achievement, index) => (
                      <li key={index}>{achievement}</li>
                    ))}
                  </ul>
                </div>

                <div className="modal-section">
                  <h3>Skills</h3>
                  <div className="skills-tags">
                    {selectedMember.skills.map((skill, index) => (
                      <span key={index} className="skill-tag">{skill}</span>
                    ))}
                  </div>
                </div>

                <div className="modal-section">
                  <h3>Connect</h3>
                  <div className="modal-social">
                    <a href={selectedMember.linkedin} target="_blank" rel="noopener noreferrer" className="social-link">
                      <FaLinkedin />
                      <span>LinkedIn</span>
                    </a>
                    <a href={selectedMember.github} target="_blank" rel="noopener noreferrer" className="social-link">
                      <FaGithub />
                      <span>GitHub</span>
                    </a>
                    <a href={`mailto:${selectedMember.email}`} className="social-link">
                      <FaEnvelope />
                      <span>Email</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* Join Team Section */}
      <section className="join-team-section">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="join-content"
          >
            <h2>Join Our Team</h2>
            <p>
              Want to be part of our amazing team? We're always looking for passionate individuals 
              who want to make a difference in the tech community.
            </p>
            <div className="join-buttons">
              <button className="btn-primary">Apply Now</button>
              <button className="btn-secondary">Learn More</button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Team;
